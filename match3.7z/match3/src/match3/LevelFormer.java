/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package match3;

import java.util.Random;

/**
 *
 * @author boso0717
 */
public class LevelFormer {
    int[][] levelMap = new int[5][5];
    
    public LevelFormer(){
        formLevelMap();
    }
    
    private void formLevelMap(){
        for (int i = 0; i < 5; i++){
            for (int k = 0; k < 5; k++){
                levelMap[i][k] = getRandomNumber();
            }
        }
    }
    
    private int getRandomNumber(){
        Random value = new Random();
        return value.nextInt(3);
    }
    
    public int[][] getLevelMap(){
        return levelMap;
    }
    
}
