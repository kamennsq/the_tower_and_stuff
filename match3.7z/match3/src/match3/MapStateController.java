/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package match3;

import java.util.Random;

/**
 *
 * @author boso0717
 */
public class MapStateController {
    int[][] level;
    int temp;
    
    public MapStateController(int[][] level){
        this.level = level;
        drawMap();      
    }
    
    private void drawMap(){
        System.out.print(level[0][0]);
        System.out.print(level[0][1]);
        System.out.print(level[0][2]);
        System.out.print(level[0][3]);
        System.out.println(level[0][4]);
        System.out.print(level[1][0]);
        System.out.print(level[1][1]);
        System.out.print(level[1][2]);
        System.out.print(level[1][3]);
        System.out.println(level[1][4]);
        System.out.print(level[2][0]);
        System.out.print(level[2][1]);
        System.out.print(level[2][2]);
        System.out.print(level[2][3]);
        System.out.println(level[2][4]);
        System.out.print(level[3][0]);
        System.out.print(level[3][1]);
        System.out.print(level[3][2]);
        System.out.print(level[3][3]);
        System.out.println(level[3][4]);
        System.out.print(level[4][0]);
        System.out.print(level[4][1]);
        System.out.print(level[4][2]);
        System.out.print(level[4][3]);
        System.out.println(level[4][4]);
        System.out.println("==========CHECKING FOR COMBOS============");
        checkCombosHorizontal_5();
        checkCombosVertical_5();
        checkCombosHorizontal_4();
        checkCombosVertical_4();
        checkCombosHorizontal_3();
        checkCombosVertical_3();
        
    }
    
    private void checkCombosHorizontal_3(){
        for (int k = 0; k < 3; k++){
            for (int i = 0; i < 5; i++){
                if (level[i][k] == level[i][k+1] && level[i][k] == level[i][k+2]){
                    level[i][k] = getRandomNumber();
                    level[i][k+1] = getRandomNumber();
                    level[i][k+2] = getRandomNumber();
                    drawMap();
                }
            }
        }
    }
    
    private void checkCombosVertical_3(){
        for (int k = 0; k < 5; k++){
            for (int i = 0; i < 3; i++){
                if (level[i][k] == level[i+1][k] && level[i][k] == level[i+2][k]){
                    level[i][k] = getRandomNumber();
                    level[i+1][k] = getRandomNumber();
                    level[i+2][k] = getRandomNumber();
                    drawMap();
                }
            }
        }
    }
    
    private void checkCombosHorizontal_4(){
        for (int k = 0; k < 2; k++){
            for (int i = 0; i < 5; i++){
                if (level[i][k] == level[i][k+1] && level[i][k] == level[i][k+2] && level[i][k] == level[i][k+3]){
                    level[i][k] = getRandomNumber();
                    level[i][k+1] = getRandomNumber();
                    level[i][k+2] = getRandomNumber();
                    level[i][k+3] = getRandomNumber();
                    drawMap();
                }
            }
        }
    }
    
    private void checkCombosVertical_4(){
        for (int k = 0; k < 5; k++){
            for (int i = 0; i < 2; i++){
                if (level[i][k] == level[i+1][k] && level[i][k] == level[i+2][k] && level[i][k] == level[i+3][k]){
                    level[i][k] = getRandomNumber();
                    level[i+1][k] = getRandomNumber();
                    level[i+2][k] = getRandomNumber();
                    level[i+3][k] = getRandomNumber();
                    drawMap();
                }
            }
        }
    }
    
    private void checkCombosHorizontal_5(){
        for (int i = 0; i < 5; i++){
            if (level[i][0] == level[i][1] && level[i][0] == level[i][2] && level[i][0] == level[i][3] && level[i][0] == level[i][4]){
                level[i][0] = getRandomNumber();
                level[i][1] = getRandomNumber();
                level[i][2] = getRandomNumber();
                level[i][3] = getRandomNumber();
                level[i][4] = getRandomNumber();
                drawMap();
            }
        }
    }
    
    private void checkCombosVertical_5(){
        for (int k = 0; k < 5; k++){
            if (level[0][k] == level[1][k] && level[0][k] == level[2][k] && level[0][k] == level[3][k] && level[0][k] == level[4][k]){
                level[0][k] = getRandomNumber();
                level[1][k] = getRandomNumber();
                level[2][k] = getRandomNumber();
                level[3][k] = getRandomNumber();
                level[4][k] = getRandomNumber();
                drawMap();
                }
        }
    }
    
    public int getRandomNumber(){
        Random value = new Random();
        return value.nextInt(3);
    }
    
    public int[][] getNewMap(int raw, int column, int raw1, int column1){
        temp = level[raw][column];
        level[raw][column] = level[raw1][column1];
        level[raw1][column1] = temp;
        drawMap();
        return level;
    }
    
}
