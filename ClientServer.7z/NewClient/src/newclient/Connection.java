
package newclient;

import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;





public class Connection {

    boolean shutdown = false;
    ArrayList list = new ArrayList();
    
    Connection(String login){
        connect(login);
    }
    
    private void connect(String login){ 
        Socket socket;
            try {
                socket = new Socket("localhost",4321);
                ConnectionThread con = new ConnectionThread(socket, login);
                list.add(con);
                Thread t = new Thread(con);
                t.start();
            } catch (IOException ex) {
                System.out.println(ex);
            }
    }
    
    public void ex(){
        send("online");
    }
    
    public void send(String message){
             getClient(0).send(message);  
    }
    
    public ConnectionThread getClient(int index){
        return((ConnectionThread)list.get(index));
    }
}
