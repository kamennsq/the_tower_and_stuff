
package newclient;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;


public class Collector {
    
    
    public void writer(ArrayList list1) throws IOException{
        FileWriter wr = new FileWriter("online.txt");
        for(int i = 0; i<list1.size();i++)
                {
                wr.write(list1.get(i).toString());
                wr.write(System.getProperty("line.separator"));
                }
        wr.flush();
        wr.close();
    }
    
    public ArrayList getOnline(){
        ArrayList list = new ArrayList();
        ArrayList list2 = new ArrayList();
        int c;
        String str = "";
        try(FileReader reader = new FileReader("online.txt")){
            while ((c = reader.read()) !=-1){
                if(c==10){list.add("");}
                else if(c==13){list.add("a");}
                else{list.add((char)c);}
            }
            for (int i = 0; i < list.size();i++){
                if (list.get(i).equals("a") | list.get(i).equals("\n")){
                    list2.add(str);
                    System.out.println(str);
                    str = "";
                }
                else {
                    str += list.get(i).toString();
                }
            }
        }
        catch(Exception e){
            System.out.println(e);
        }
        return list2;
    }
}
