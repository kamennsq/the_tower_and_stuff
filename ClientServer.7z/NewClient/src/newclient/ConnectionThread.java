
package newclient;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.JOptionPane;



public class ConnectionThread implements Runnable{
    Socket s;
    private InputStreamReader inStream;
    private OutputStreamWriter outStream;
    private Scanner scanner;
    private String message;
    private PrintWriter out;
    private boolean shutdown = false;
    private boolean logining;
    private final String login;
    private String myLogin;
    ArrayList list = new ArrayList();
    public static ConnectionThread ct;
    Fight frame = new Fight();
    
    ConnectionThread(Socket s, String login){
        ct = this;
        this.s = s;
        this.login = login;
    }

    @Override
    public void run() {
        try{
            inStream =new InputStreamReader(s.getInputStream(),"UTF8");
            outStream=new OutputStreamWriter(s.getOutputStream(),"UTF8");
            scanner=new Scanner(inStream);
            out=new PrintWriter(outStream,true);
            out.println("myLogin");
            out.println(login);
            while(!shutdown && scanner.hasNextLine()){
                message = scanner.nextLine(); 
                System.out.println(message);
                if(message.equals("online")){
                    list.removeAll(list);
                    while (scanner.hasNextLine()){
                        message = scanner.nextLine();
                        if(message.equals("end")){
                            break;
                        }
                        else{
                            list.add(message);
                        }
                    }
                    Collector col = new Collector();
                    col.writer(list); 
                }
                if(message.equals("fight")){
                        myLogin = scanner.nextLine();
                       int result = JOptionPane.showConfirmDialog(null, "Игрок "+myLogin+" бросил вам вызов", "Вызов", JOptionPane.YES_NO_OPTION);
                       if(result == JOptionPane.YES_OPTION){
                          out.println("yes");
                          out.println(myLogin);
                        }
                       else{
                           out.println("no");
                           out.println(myLogin);
                        }
                   
                }
                if(message.equals("yes")){
                    JOptionPane.showMessageDialog(null, "Противник согласился", "Вызов", JOptionPane.INFORMATION_MESSAGE);
                }
                if(message.equals("no")){
                    JOptionPane.showMessageDialog(null, "Противник отказался", "Вызов", JOptionPane.INFORMATION_MESSAGE);
                }
                if(message.equals("startfight")){
                    String hp = scanner.nextLine();
                    String hp1 = scanner.nextLine();
                    String r = scanner.nextLine();
                    frame.setVisible(true);
                    InnerFrame.inf.setVisible(false);
                    fight(hp,hp1);
                    if(r.equals("0")){
                        frame.notAllow();
                    }
                    else{
                        frame.allow();
                    }
                }
                if(message.equals("yourdamage")){
                    String hp = scanner.nextLine();
                    String hp1 = scanner.nextLine();
                    fight(hp, hp1);
                    frame.allow();
                }
                if(message.equals("damage")){
                    String hp = scanner.nextLine();
                    String hp1 = scanner.nextLine();
                    setHP(hp, hp1);
                }
                if(message.equals("Victory")){
                    JOptionPane.showMessageDialog(null, "Вы победили!", "Победа", JOptionPane.INFORMATION_MESSAGE);
                    frame.setVisible(false);
                    InnerFrame.inf.setVisible(true);
                }
                if(message.equals("Defeat")){
                    JOptionPane.showMessageDialog(null, "Вы проиграли!", "Поражение", JOptionPane.INFORMATION_MESSAGE);
                    frame.setVisible(false);
                    InnerFrame.inf.setVisible(true);
                }
                if(message.equals("Draw")){
                    JOptionPane.showMessageDialog(null, "Ничья!", "Ничья", JOptionPane.INFORMATION_MESSAGE);
                    frame.setVisible(false);
                    InnerFrame.inf.setVisible(true);
                }
                if(message.equals("banned")){
                    JOptionPane.showMessageDialog(null, "Вас забанили!", "Бан", JOptionPane.INFORMATION_MESSAGE);
                    send("banned");
                    InnerFrame.inf.dispose();
                    break;
                }
                if(message.equals("0")){
                    frame.notAllow();
                }
                if(message.equals("1")){
                    frame.allow();
                }
            }

        }

        catch(Exception e){
            System.out.println(e);
        }
        finally{
            shutdown = true;
            try {
                          inStream.close();
                          shutdown=true; 
                          s.close();
                          s=null;
                        } catch (IOException ex) {
                           System.out.println("Client thread error:  "+ex.getMessage());
                        }
        }
    }
    
    public void send(String msg){
        out.println(msg);
    }
    
    private void fight(String hp, String hp1){       
        frame.setter(hp, hp1);
    }
    
    private void setHP(String hp, String hp1){
        frame.setter(hp, hp1);        
    }
    
}
