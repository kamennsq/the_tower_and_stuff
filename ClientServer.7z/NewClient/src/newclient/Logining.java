
package newclient;

import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;
//import java.util.*;


public class Logining {
    //private boolean shutdown=false;
    private InputStreamReader inStream;
    private OutputStreamWriter outStream;
    private Scanner scanner;
    private String message;
    private PrintWriter out;
    private String login;
    private String pass;
    private String what;
    

    
    public void registr(String info, String login, String pass){
        Socket socket;    
        try{
            socket = new Socket("localhost",4321);
                try{
                    inStream =new InputStreamReader(socket.getInputStream(),"UTF8");
                    outStream=new OutputStreamWriter(socket.getOutputStream(),"UTF8");
                    scanner=new Scanner(inStream);
                    out=new PrintWriter(outStream,true);
                    what = info;
                    this.login = login;
                    this.pass = pass;
                    sender();
                    while(scanner.hasNextLine()){
                            message=scanner.nextLine();
                            if(message.equals("true") | message.equals("false")){
                                break;
                            }
                        }
                }
                catch(Exception e){
                    System.out.println(e);
                    socket.close();
                }
                finally{
                    socket.close();
                }
        }
        catch(UnknownHostException ex){
            System.out.println(ex);
        }
        catch (IOException ex){
            System.out.println(ex);
        }
    }
    
    private void sender(){
        out.println(this.what);
        out.println(this.login);
        out.println(this.pass);
    }
    
    public String returner(){
        return message;
    }
    
}
