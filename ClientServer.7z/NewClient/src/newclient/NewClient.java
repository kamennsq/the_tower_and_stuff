
package newclient;


public class NewClient {

   
    public static void main(String[] args) {
        LoginPage.main(args);
    }
    
}
