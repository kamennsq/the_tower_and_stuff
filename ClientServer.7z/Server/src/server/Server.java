package server;


public class Server {

    
    public static void main(String[] args) {
        Frame.main(args);
        Control control = new Control();

    }
    
}
