package server;

import java.io.*;
import java.util.*;

public class Loader {
    public List loadLogins()throws UnsupportedEncodingException, FileNotFoundException, IOException{
        List list = new ArrayList();
        List list2 = new ArrayList();
        FileInputStream reader = new FileInputStream("logins.txt");
        BufferedInputStream bis = new BufferedInputStream(reader);
        int c;
        String str = "";
        try{
            while ((c = bis.read()) !=-1){
                if (c == 10){list.add("");}
                else if(c == 13){list.add(" ");}
                else {list.add((char)c);}
            }
            for (int i = 0; i < list.size();i++){
                if (list.get(i).equals(" ") | list.get(i).equals("\n")){
                    list2.add(str);    
                    str = "";                         
                }
                else {
                    str += list.get(i).toString();
                }
            }
        }
        catch(Exception e){
            System.out.println(e);
        }
        return list2;
    }
    public List loadPass()throws UnsupportedEncodingException, FileNotFoundException, IOException{
        List list = new ArrayList();
        List list2 = new ArrayList();
        FileInputStream reader = new FileInputStream("pass.txt");
        BufferedInputStream bis = new BufferedInputStream(reader);
        int c;
        String str = "";
        try{
            while ((c = bis.read()) !=-1){
                if (c == 10){list.add("");}
                else if(c == 13){list.add(" ");}
                else {list.add((char)c);}
            }
            for (int i = 0; i < list.size();i++){
                if (list.get(i).equals(" ") | list.get(i).equals("\n")){
                    list2.add(str);
                    str = "";
                }
                else {
                    str += list.get(i).toString();
                }
            }
        }
        catch(Exception e){
            System.out.println(e);
        }
        return list2;
    }
    
    public List loadBanned()throws UnsupportedEncodingException, FileNotFoundException, IOException{
        List list = new ArrayList();
        List list2 = new ArrayList();
        FileInputStream reader = new FileInputStream("ban.txt");
        BufferedInputStream bis = new BufferedInputStream(reader);
        int c;
        String str = "";
        try{
            while ((c = bis.read()) !=-1){
                if (c == 10){list.add("");}
                else if(c == 13){list.add(" ");}
                else {list.add((char)c);}
            }
            for (int i = 0; i < list.size();i++){
                if (list.get(i).equals(" ") | list.get(i).equals("\n")){
                    list2.add(str);    
                    str = "";                         
                }
                else {
                    str += list.get(i).toString();
                }
            }
        }
        catch(Exception e){
            System.out.println(e);
        }
        return list2;
    }
}
