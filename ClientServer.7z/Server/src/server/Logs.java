
package server;

import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class Logs {
    
    
    public void registrLog(String login){
        List list = new ArrayList();
        List list2 = new ArrayList();
        int c;
        String str = "";
        try(FileReader reader = new FileReader("registrLog.txt")){
            while ((c = reader.read()) !=-1){
                if(c==10){list.add("");}
                else if(c==13){list.add("a");}
                else{list.add((char)c);}
            }
            for (int i = 0; i < list.size();i++){
                if (list.get(i).equals("a") | list.get(i).equals("\n")){
                    list2.add(str);
                    str = "";
                }
                else {
                    str += list.get(i).toString();
                }
            }
        }
        catch(Exception e){
            System.out.println(e);
        }
        Date current = new Date();
        list2.add(login + " successfully registered " + current);
        try{
            FileWriter writer2 = new FileWriter("registrLog.txt");
                for(int i = 0; i<list2.size();i++){
                    writer2.write(list2.get(i).toString());
                    writer2.write(System.getProperty("line.separator"));
                }
            writer2.flush();
            writer2.close();
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
    
    public void onlineLog(String login, int p){
        List list = new ArrayList();
        List list2 = new ArrayList();
        int c;
        String str = "";
        try(FileReader reader = new FileReader("onlineLog.txt")){
            while ((c = reader.read()) !=-1){
                if(c==10){list.add("");}
                else if(c==13){list.add("a");}
                else{list.add((char)c);}
            }
            for (int i = 0; i < list.size();i++){
                if (list.get(i).equals("a") | list.get(i).equals("\n")){
                    list2.add(str);
                    str = "";
                }
                else {
                    str += list.get(i).toString();
                }
            }
        }
        catch(Exception e){
            System.out.println(e);
        }
        if(p==0){
            Date current = new Date();
            list2.add(login + " successfully loged in " + current);
            try{
                FileWriter writer2 = new FileWriter("onlineLog.txt");
                    for(int i = 0; i<list2.size();i++){
                        writer2.write(list2.get(i).toString());
                        writer2.write(System.getProperty("line.separator"));
                    }
                writer2.flush();
                writer2.close();
            }
            catch(Exception e){
                 System.out.println(e);
            }
        }
        else{
            Date current = new Date();
        list2.add(login + " successfully loged out " + current);
        try{
            FileWriter writer2 = new FileWriter("onlineLog.txt");
                for(int i = 0; i<list2.size();i++){
                    writer2.write(list2.get(i).toString());
                    writer2.write(System.getProperty("line.separator"));
                }
            writer2.flush();
            writer2.close();
        }
        catch(Exception e){
            System.out.println(e);
        }
        }
    }
    
    public void fightLog(int p){
        List list = new ArrayList();
        List list2 = new ArrayList();
        int c;
        String str = "";
        try(FileReader reader = new FileReader("fightLog.txt")){
            while ((c = reader.read()) !=-1){
                if(c==10){list.add("");}
                else if(c==13){list.add("a");}
                else{list.add((char)c);}
            }
            for (int i = 0; i < list.size();i++){
                if (list.get(i).equals("a") | list.get(i).equals("\n")){
                    list2.add(str);
                    str = "";
                }
                else {
                    str += list.get(i).toString();
                }
            }
        }
        catch(Exception e){
            System.out.println(e);
        }
        if(p==0){
            Date current = new Date();
            list2.add("Battle successfully started " + current);
            try{
                FileWriter writer2 = new FileWriter("fightLog.txt");
                    for(int i = 0; i<list2.size();i++){
                        writer2.write(list2.get(i).toString());
                        writer2.write(System.getProperty("line.separator"));
                    }
                writer2.flush();
                writer2.close();
            }
            catch(Exception e){
                 System.out.println(e);
            }
        }
        else{
            Date current = new Date();
        list2.add("Battle successfully finished " + current);
        try{
            FileWriter writer2 = new FileWriter("fightLog.txt");
                for(int i = 0; i<list2.size();i++){
                    writer2.write(list2.get(i).toString());
                    writer2.write(System.getProperty("line.separator"));
                }
            writer2.flush();
            writer2.close();
        }
        catch(Exception e){
            System.out.println(e);
        }
        }
    }
    
    public void banLog(String login){
        List list = new ArrayList();
        List list2 = new ArrayList();
        int c;
        String str = "";
        try(FileReader reader = new FileReader("banLog.txt")){
            while ((c = reader.read()) !=-1){
                if(c==10){list.add("");}
                else if(c==13){list.add("a");}
                else{list.add((char)c);}
            }
            for (int i = 0; i < list.size();i++){
                if (list.get(i).equals("a") | list.get(i).equals("\n")){
                    list2.add(str);
                    str = "";
                }
                else {
                    str += list.get(i).toString();
                }
            }
        }
        catch(Exception e){
            System.out.println(e);
        }
        Date current = new Date();
        list2.add(login + " was banned " + current);
        try{
            FileWriter writer2 = new FileWriter("banLog.txt");
                for(int i = 0; i<list2.size();i++){
                    writer2.write(list2.get(i).toString());
                    writer2.write(System.getProperty("line.separator"));
                }
            writer2.flush();
            writer2.close();
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
    
    public void ban(String login){
        List list = new ArrayList();
        List list2 = new ArrayList();
        int c;
        String str = "";
        try(FileReader reader = new FileReader("ban.txt")){
            while ((c = reader.read()) !=-1){
                if(c==10){list.add("");}
                else if(c==13){list.add("a");}
                else{list.add((char)c);}
            }
            for (int i = 0; i < list.size();i++){
                if (list.get(i).equals("a") | list.get(i).equals("\n")){
                    list2.add(str);
                    str = "";
                }
                else {
                    str += list.get(i).toString();
                }
            }
        }
        catch(Exception e){
            System.out.println(e);
        }
        list2.add(login);
        try{
            FileWriter writer2 = new FileWriter("ban.txt");
                for(int i = 0; i<list2.size();i++){
                    writer2.write(list2.get(i).toString());
                    writer2.write(System.getProperty("line.separator"));
                }
            writer2.flush();
            writer2.close();
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
}
