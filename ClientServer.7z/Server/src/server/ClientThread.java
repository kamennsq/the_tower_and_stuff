package server;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Random;
import java.util.Scanner;

public class ClientThread implements Runnable {
    Socket s;
    private boolean shutdown = false;
    private InputStreamReader inStream;
    private PrintWriter out;
    private String login;
    //private String login1;
    private String enemyLogin;

    ClientThread(Socket s){
        this.s = s;
    }

    @Override
    public void run() {
       Checker check = new Checker ();  
       Logs log = new Logs();
        while(s != null){
            try {
                inStream = new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8);
                OutputStreamWriter outStream = new OutputStreamWriter(s.getOutputStream(), StandardCharsets.UTF_8);
                Scanner scanner = new Scanner(inStream);
                out = new PrintWriter(outStream,true);
                out.println("Welcome!");

                while(!shutdown&& scanner.hasNextLine()){
                    String message = scanner.nextLine();
                    System.out.println(message);

                    if (message.equals("registr")){
                        login = scanner.nextLine();
                        String pass = scanner.nextLine();
                        System.out.println(login);
                        System.out.println(pass);
                        out.println(check.compare(login, pass));
                        log.registrLog(login);
                        login = null;
                    }

                    if (message.equals("login")){
                        login = scanner.nextLine();
                        String pass = scanner.nextLine();
                        System.out.println(login);
                        System.out.println(pass);
                        out.println(check.logining(login, pass));
                        login = null;
                    }

                    if (message.equals("myLogin")){
                        login = scanner.nextLine();
                        check.addOnline(login);
                        log.onlineLog(login,0);
                    }

                    if (message.equals("online")){
                        out.println("online");
                        for (Object o : check.getOnline()) {
                            if (!o.toString().equals(login)) {
                                Send(o.toString());
                            }
                        }
                        Send("end");
                    }

                    if (message.equals("fight")){
                        enemyLogin = scanner.nextLine();
                        Control._control.SendAll("fight", enemyLogin, login);
                    }

                    if (message.equals("yes")){
                        enemyLogin = scanner.nextLine();
                        Control._control.SendAll("yes", enemyLogin, login);
                        out.println("startfight");
                        Random random = new Random();
                        int r = random.nextInt(2);
                        String HP1 = "1000";
                        String HP = "1000";
                        Send(HP);
                        Send(HP1);
                        if (r == 0){
                            Send("0");
                            Control._control.sendFight(HP, HP1, 1, enemyLogin);
                        }
                        else{
                            Send("1");
                            Control._control.sendFight(HP, HP1, 0, enemyLogin);
                        }
                        log.fightLog(0);
                    }

                    if (message.equals("no")){
                        enemyLogin = scanner.nextLine();
                        Control._control.SendAll("no", enemyLogin, login);
                    }

                    if (message.equals("damage")){
                        String hp2 = scanner.nextLine();
                        String hp3 = scanner.nextLine();
                        sendHP(hp2, hp3);
                        Control._control.sendDamage(hp3, hp2, enemyLogin);
                    }

                    if (message.equals("I win")){
                        Send("Victory");
                        Control._control.sendResult("Defeat", enemyLogin);
                        log.fightLog(1);
                    }

                    if (message.equals("I lose")){
                        Send("Defeat");
                        Control._control.sendResult("Victory", enemyLogin);
                        log.fightLog(1);
                    }

                    if (message.equals("Draw")){
                        Send("Draw");
                        Control._control.sendResult("Draw", enemyLogin);
                        log.fightLog(1);
                    }

                    if (message.equals("banned")){
                        log.banLog(login);
                        log.ban(login);
                    }
                }
            } catch (IOException ex) {
                System.out.println("Error initialization clients streams:  " + ex.getMessage());
            }finally{
                try {
                    out.flush();
                    out.close();
                    inStream.close();
                    shutdown = true;
                    s.close();
                    s = null;
                    Control._control.ShutdownClient(this);
                    System.out.println("Client disconnect");
                    check.deleteOnline(login);
                    if(login != null){
                        log.onlineLog(login, 1);
                    }
                } catch (IOException ex) {
                    System.out.println("Client thread error:  " + ex.getMessage());
                }
                    }
        }
    }

    public void Send(String s){
        out.println(s);        
    }
    
    public String getLogin(){
        return login;
    }

    public void sendHP(String hp2, String hp3){
        out.println("damage");
        out.println(hp2);
        out.println(hp3);
    }
}
