package server;
import java.util.*;
import java.io.*;

public class Checker {
    List logins = new ArrayList();
    List passes = new ArrayList();
    //List pers = new ArrayList();
    List<String> online = new ArrayList<>();
    List banned = new ArrayList();


    
    public boolean compare(String login,String pass){
        try{
            Loader load = new Loader();
            logins = load.loadLogins();
            //passes = load.loadPass();
            for (Object o : logins) {
                if (login.equals(o)) {
                    return false;
                }
            }
        }
        catch(Exception e){
            System.out.println(e);
        }
        save(login, pass);
        return true;
    }
    
    public boolean logining(String login, String pass){
        try{
            Loader load = new Loader();
            logins = load.loadLogins();
            passes = load.loadPass();
            online = getOnline();
            banned = load.loadBanned();
            for (Object o : banned) {
                if (login.equals(o)) {
                    return false;
                }
            }
            for (Object o : online) {
                if (login.equals(o)) {
                    return false;
                }
            }
            for (int i = 0; i < logins.size(); i++){
                if (login.equals(logins.get(i)) & pass.equals(passes.get(i))){
                    return true;
                }
            }
        }
        catch(Exception e){
            System.out.println(e);
        }
        return false;
    }
    
    private void save(String login, String pass){
        logins.add(login);
        passes.add(pass);
        try{
                FileWriter writer = new FileWriter("logins.txt");
                FileWriter writer1 = new FileWriter("pass.txt");
            for (Object o : logins) {
                writer.write(o.toString());
                writer.write(System.getProperty("line.separator"));
            }
            for (Object o : passes) {
                writer1.write(o.toString());
                writer1.write(System.getProperty("line.separator"));
            }
                writer.flush();
                writer1.flush();
                writer.close();
                writer1.close();
        }
        catch (IOException ex){ex.printStackTrace();}
    }
    
    public void addOnline(String login) throws IOException{
        List<Serializable> list = new ArrayList<>();
        List<String> list2 = new ArrayList<>();
        int c;
        String str = "";
        try(FileReader reader = new FileReader("online.txt")){
            while ((c = reader.read()) != -1){
                if(c == 10){list.add("");}
                else if(c == 13){list.add("a");}
                else{list.add((char)c);}
            }
            for (Serializable serializable : list) {
                if (serializable.equals("a") | serializable.equals("\n")) {
                    list2.add(str);
                    str = "";
                } else {
                    str += serializable.toString();
                }
            }
        }
        catch(Exception e){
            System.out.println(e);
        }
        list2.add(login);
        FileWriter writer2 = new FileWriter("online.txt");
        for (String s : list2) {
            writer2.write(s.toString());
            writer2.write(System.getProperty("line.separator"));
        }
        writer2.flush();
        writer2.close();
    }
    
    public void deleteOnline(String login) throws IOException{
        List<Serializable> list = new ArrayList<>();
        List<String> list2 = new ArrayList<String>();
        List<String> list3 = new ArrayList<>();
        int c;
        String str = "";
        try(FileReader reader = new FileReader("online.txt")){
            while ((c = reader.read()) !=-1){
                if(c == 10){list.add("");}
                else if(c == 13){list.add("a");}
                else{list.add((char)c);}
            }
            for (Serializable serializable : list) {
                if (serializable.equals("a") | serializable.equals("\n")) {
                    list2.add(str);
                    str = "";
                } else {
                    str += serializable.toString();
                }
            }
        }
        catch(Exception e){
            System.out.println(e);
        }
        for (String s : list2) {
            if (!s.equals(login)) {
                list3.add(s);
            }
        }
        FileWriter writer2 = new FileWriter("online.txt");
        for (String s : list3) {
            writer2.write(s.toString());
            writer2.write(System.getProperty("line.separator"));
        }
                writer2.flush();
                writer2.close();
    }
    
    public ArrayList<String> getOnline(){
        ArrayList<Serializable> list = new ArrayList<Serializable>();
        ArrayList<String> list2 = new ArrayList<>();
        int c;
        String str = "";
        try(FileReader reader = new FileReader("online.txt")){
            while ((c = reader.read()) !=-1){
                if(c == 10){list.add("");}
                else if(c == 13){list.add("a");}
                else{list.add((char)c);}
            }
            for (Serializable serializable : list) {
                if (serializable.equals("a") | serializable.equals("\n")) {
                    list2.add(str);
                    str = "";
                } else {
                    str += serializable.toString();
                }
            }
        }
        catch(Exception e){
            System.out.println(e);
        }
        return list2;
    }
}
