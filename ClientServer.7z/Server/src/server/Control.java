package server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class Control {
    private boolean shutdown=false;
    public static Control _control;
    ArrayList clientList=new ArrayList();
    ArrayList clientList1 = new ArrayList();
    Control(){
            _control=this;
            StartServer();
    }
    private void StartServer(){
        try {
            ServerSocket ss=new ServerSocket(4321);
            System.out.println("Server started");
            System.out.println("Connection wait...");
            while(!shutdown){
                Socket incoming=ss.accept();
                System.out.println("Client connected");
                ClientThread client=new ClientThread(incoming);
                clientList.add(client);
                Thread t=new Thread(client);
                t.start();
            }
        } catch (IOException ex) {
            System.out.println("Server internal error "+ex.getMessage());
        }
    }
    public void ShutdownClient(ClientThread c){
        clientList.remove(c);        
    }
    public void SendAll(String message,String login, String myLogin){
        getThread(login).Send(message);
        getThread(login).Send(myLogin);
        System.out.println(message);
    }
    public void sendFight(String hp, String hp1, int r, String login){
        getThread(login).Send("startfight");
        getThread(login).Send(hp);
        getThread(login).Send(hp1);
        getThread(login).Send(Integer.toString(r));
    }
    public void sendDamage(String hp, String hp1, String login){
        getThread(login).Send("yourdamage");
        getThread(login).Send(hp);
        getThread(login).Send(hp1);
    }
    public void sendResult(String message, String login){
        getThread(login).Send(message);
    }
    public ClientThread getClient(int index){
        return((ClientThread)clientList.get(index));
    }
    
    public int getClientNum(ClientThread c){
        return(clientList.indexOf(c));
    }
    
    private ClientThread getThread(String login){
        for(int i = 0; i<clientList.size(); i++){
           ClientThread thread = getClient(i);
           if(thread.getLogin().equals(login)){
              return(thread);
           }
        }     
        return(null);
    }
    
    public void ban(String login){
        try{
            getThread(login).Send("banned");
        }
        catch(NullPointerException e){
            Logs log = new Logs();
            log.ban(login);
        }
    }
    
}
