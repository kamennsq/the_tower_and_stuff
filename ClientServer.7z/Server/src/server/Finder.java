
package server;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;


public class Finder {
    
    //private List list;
    private String login;
    
    Finder(String login){
        this.login = login;
    }
    
    
    public List getInfo() throws FileNotFoundException{
        List list = new ArrayList();
        List list2 = new ArrayList();
        int c;
        String str = "";
        try(FileReader reader = new FileReader(login+".txt")){
            while ((c = reader.read()) !=-1){
                if(c==10){list.add("");}
                else if(c==13){list.add("a");}
                else{list.add((char)c);}
            }
            for (int i = 0; i < list.size();i++){
                if (list.get(i).equals("a") | list.get(i).equals("\n")){
                    list2.add(str);
                    str = "";
                }
                else {
                    str += list.get(i).toString();
                }
            }
        }
        catch(Exception e){
            System.out.println(e);
        }
        return list2;
    }
}
